package com.example.question.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class UsersDetails {
	
	  private String userName;
	  private int reputationScore;
	  private int numberOfGoldBadges;
	  private int numberOfBronzeBadges;
	  private int numberOfSilverBadges;  
	
}
