package com.example.question.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.question.model.QuestionsList;
import com.example.question.service.QuestionService;

@RestController
@RequestMapping("/question")
public class QuestionController {
		
	
	@Autowired
	private QuestionService questionService;
	
	@PostMapping("/Question")
	public ResponseEntity<Object> saveOrUpdateQuestion(@RequestBody QuestionsList questionList)  {		
	 try {
		     questionService.getQuestion(questionList.getQuestionId());
		  	 try {
		  		 return new ResponseEntity<>(questionService.updateQuestion(questionList),HttpStatus.OK);
			 } catch (Exception e1) { 
				 return new ResponseEntity<>(e1.getMessage(),HttpStatus.BAD_REQUEST);
			 }
	 }catch (Exception e) {
		 	 try {
		 		return new ResponseEntity<>(questionService.addQuestion(questionList),HttpStatus.OK);
			 } catch (Exception e1) { 
		 		return new ResponseEntity<>(e1.getMessage(),HttpStatus.BAD_REQUEST);
	 		 }
   	  }  
	}
			
	@PostMapping("/Questions")
	public ResponseEntity<Object> saveOrUpdateQuestions(@RequestBody QuestionsList questionList){		
	  try {
		  questionService.getQuestions(questionList.getQuestionId());
		  try {
			  return new ResponseEntity<>(questionService.updateQuestions(questionList),HttpStatus.OK);
		  } catch (Exception e1) { 
			  return new ResponseEntity<>(e1.getMessage(),HttpStatus.BAD_REQUEST);
		  }
	  } catch (Exception e) { 
		  try {
			  return new ResponseEntity<>(questionService.addQuestions(questionList),HttpStatus.OK);
		  } catch (Exception e1) { 
			  return new ResponseEntity<>(e1.getMessage(),HttpStatus.BAD_REQUEST);
		  }

   	  }  
	}
	
}
