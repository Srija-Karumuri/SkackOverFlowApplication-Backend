package com.example.question.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(Include.NON_DEFAULT)
@Table("jdbc")
public class QuestionsList {
	
		@Id
		private int questionId;
	    private String questionName;
	    private String description;
	    private int numberOfVotes;
	    private int numberOfViews;
	    private String createdOn;
	    private String modifiedOn;
	    private TagsList tagsList;
	    private UsersDetails usersDetails;
	   
	   
}
