package com.example.question.service;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

import com.example.question.model.QuestionsList;

import reactor.core.publisher.Mono;

@Service
public class QuestionService {
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private WebClient.Builder webClient;
	
	String url = "http://QUESTIONJDBCSTRUCTURE/questions/";
	
	HttpHeaders httpHeaders = new HttpHeaders();
	
	public Object getQuestion(@PathVariable int id)  {	
		httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity <String> entity = new HttpEntity<>(httpHeaders);	
	    return restTemplate.exchange(url+id, HttpMethod.GET, entity, Object.class).getBody();
	}
	
	public Object addQuestion(@RequestBody QuestionsList questionList)  {	
		httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<QuestionsList> entity = new HttpEntity<>(questionList,httpHeaders);	
		return restTemplate.exchange(url+"addQuestion", HttpMethod.POST, entity, Object.class).getBody();			
	}
	
	public Object updateQuestion(@RequestBody QuestionsList questionList)  {	
		httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<QuestionsList> entity = new HttpEntity<>(questionList,httpHeaders);
		return restTemplate.exchange(url+questionList.getQuestionId(), HttpMethod.PUT, entity, Object.class).getBody();	
	}
	
	public Object getQuestions(@PathVariable int id)  {	
		return webClient.build().get().uri(url+id).retrieve().bodyToMono(Object.class).block();	
	}
	
	public Object addQuestions(@RequestBody QuestionsList questionList)  {	
		return webClient.build().post().uri(url+"addQuestion").body(Mono.just(questionList), QuestionsList.class).retrieve().bodyToMono(Object.class).block();	
	}
	
	public Object updateQuestions(@RequestBody QuestionsList questionList)  {	
		return webClient.build().put().uri(url+questionList.getQuestionId()).body(Mono.just(questionList), QuestionsList.class).retrieve().bodyToMono(Object.class).block();	
	}
}
