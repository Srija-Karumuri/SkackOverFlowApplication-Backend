package com.example.question.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import com.example.question.model.QuestionsList;
import com.example.question.model.TagsList;
import com.example.question.model.UsersDetails;
import com.example.question.service.QuestionService;

@SpringBootTest
class QuestionControllerTests {
	
	@InjectMocks
	private QuestionController questionController;
	
	@Mock
	private QuestionService questionService;
	
	@Test
	void updateQuestionTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    Object object =questionList;
	    when(questionService.getQuestion(questionList.getQuestionId())).thenReturn(object);  
	    when(questionService.updateQuestion(questionList)).thenReturn(object);
	    assertEquals(HttpStatus.OK,questionController.saveOrUpdateQuestion(questionList).getStatusCode());

	}
	
	@Test
	void updateQuestionExceptionTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    Object object =questionList;
	    when(questionService.getQuestion(questionList.getQuestionId())).thenReturn(object);  
	    when(questionService.updateQuestion(questionList)).thenThrow(HttpClientErrorException.class);
	    assertEquals(HttpStatus.BAD_REQUEST,questionController.saveOrUpdateQuestion(questionList).getStatusCode());

	}
	
	
	@Test
	void addQuestionTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    Object object =questionList;
	    when(questionService.getQuestion(questionList.getQuestionId())).thenThrow(HttpClientErrorException.class);  
	    when(questionService.addQuestion(questionList)).thenReturn(object);
	    assertEquals(HttpStatus.OK,questionController.saveOrUpdateQuestion(questionList).getStatusCode());

	}
	
	@Test
	void addQuestionExceptionTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    when(questionService.getQuestion(questionList.getQuestionId())).thenThrow(HttpClientErrorException.class);  
	    when(questionService.addQuestion(questionList)).thenThrow(HttpClientErrorException.class);  
	    assertEquals(HttpStatus.BAD_REQUEST,questionController.saveOrUpdateQuestion(questionList).getStatusCode());

	}
	
	@Test
	void updateQuestionsTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    Object object =questionList;
	    when(questionService.getQuestion(questionList.getQuestionId())).thenReturn(object);  
	    when(questionService.updateQuestions(questionList)).thenReturn(object);
	    assertEquals(HttpStatus.OK,questionController.saveOrUpdateQuestions(questionList).getStatusCode());

	}
	
	@Test
	void updateQuestionsExceptionTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    Object object =questionList;
	    when(questionService.getQuestion(questionList.getQuestionId())).thenReturn(object);  
	    when(questionService.updateQuestions(questionList)).thenThrow(HttpClientErrorException.class);
	    assertEquals(HttpStatus.BAD_REQUEST,questionController.saveOrUpdateQuestions(questionList).getStatusCode());

	}
	
	
	@Test
	void addQuestionsTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    Object object =questionList;
	    when(questionService.getQuestions(questionList.getQuestionId())).thenThrow(HttpClientErrorException.class);  
	    when(questionService.addQuestions(questionList)).thenReturn(object);
	    assertEquals(HttpStatus.OK,questionController.saveOrUpdateQuestions(questionList).getStatusCode());

	}
	
	@Test
	void addQuestionsExceptionTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    when(questionService.getQuestions(questionList.getQuestionId())).thenThrow(HttpClientErrorException.class);  
	    when(questionService.addQuestions(questionList)).thenThrow(HttpClientErrorException.class);  
	    assertEquals(HttpStatus.BAD_REQUEST,questionController.saveOrUpdateQuestions(questionList).getStatusCode());

	}
}
