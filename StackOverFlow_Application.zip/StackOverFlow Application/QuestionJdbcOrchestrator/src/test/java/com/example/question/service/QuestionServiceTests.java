package com.example.question.service;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;

import org.junit.jupiter.api.Test;
import com.example.question.model.QuestionsList;
import com.example.question.model.TagsList;
import com.example.question.model.UsersDetails;

@SpringBootTest
class QuestionServiceTests {
	
	@InjectMocks
	private QuestionService questionService;
	
	@Mock
	private WebClient.Builder webClient;
	
	@Mock
	private RestTemplate restTemplate;
//	RestTemplate restTemplate = new RestTemplate();
	
	String url = "http://localhost:9070/questions/";
	
	@Test
	void addOrUpdateQuestionTest() 
	{
		QuestionsList questionList= new QuestionsList();
		UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    Object object =questionList;
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<QuestionsList> entity = new HttpEntity<>(questionList,httpHeaders);
		when(restTemplate.exchange(url+"addQuestion", HttpMethod.POST, entity, Object.class).getBody()).thenReturn(object);
		assertEquals(object,questionService.addQuestion(questionList));
	}
	
//	@Test
//	void addOrUpdateQuestionTest() 
//	{
//		QuestionsList questionList= new QuestionsList();
//		UsersDetails userDetails = new UsersDetails();
//	    TagsList tagsList = new TagsList();
//	    questionList.setQuestionId(1);
//	    questionList.setQuestionName("What is Java?");
//	    questionList.setDescription("Java is an object oriented programming");
//	    questionList.setNumberOfVotes(22);
//	    questionList.setNumberOfViews(547);
//	    questionList.setCreatedOn("2022-11-24 16:39:39");
//	    questionList.setModifiedOn("2022-11-25 12:51:39");
//	    tagsList.setField1("sql");
//	    tagsList.setField2("sql-server");
//	    userDetails.setUserName("Srija");
//	    userDetails.setReputationScore(1500);
//	    userDetails.setNumberOfGoldBadges(12);
//	    userDetails.setNumberOfBronzeBadges(2);
//	    userDetails.setNumberOfSilverBadges(3);
//	    questionList.setTagsList(tagsList);
//	    questionList.setUsersDetails(userDetails);
//	    Object object =questionList;
//	    
////	questionController.execute(Mockito.anyString(), Mockito.any(), Mockito.any(), 
////          Mockito.any(), Mockito.any());
//	
//
////	Mockito.verify(restTemplate, Mockito.times(1))
////           .exchange(Mockito.anyString(),
////                           Mockito.<HttpMethod> any(),
////                           Mockito.<HttpEntity<?>> any(),
////                           Mockito.<Class<?>> any(),
////                           Mockito.<String, String> anyMap());
//	HttpHeaders httpHeaders = new HttpHeaders();
//	httpHeaders.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
//	HttpEntity<QuestionsList> entity = new HttpEntity<>(questionList,httpHeaders);
//	when(restTemplate.exchange(url+"addQuestion", HttpMethod.POST, entity, Object.class).getBody()).thenReturn(object);
//
//	assertEquals(object,questionService.addQuestion(questionList));
////	Mockito.verify(restTemplate, Mockito.times(1))
////  .exchange("http://localhost:8282/questions/addQuestion", HttpMethod.POST, entity, Object.class).getBody();
////	HttpStatus responseEntity= restTemplate.exchange("http://QUESTIONJDBCSTRUCTURE/questions/", HttpMethod.POST, entity, Object.class).getStatusCode();
////	questionService.addQuestion(questionList);
////	assertEquals(HttpStatus.OK, responseEntity);
//
//	}

}
