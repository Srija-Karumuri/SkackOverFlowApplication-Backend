package com.example.question.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserDetailsTest {
	
	@InjectMocks
	private UsersDetails usersDetails;
	
	@Test
	void pagingListTest(){
		usersDetails.getUserName();
		usersDetails.getReputationScore();
		usersDetails.getNumberOfGoldBadges();
		usersDetails.getNumberOfBronzeBadges();
		usersDetails.getNumberOfSilverBadges();
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	private void doNotThrowException(){
	    //This method will never throw exception
	}

}
