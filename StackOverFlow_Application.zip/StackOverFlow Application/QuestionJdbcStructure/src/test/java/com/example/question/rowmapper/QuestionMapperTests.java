package com.example.question.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import com.example.question.model.QuestionsList;
import com.example.question.model.TagsList;
import com.example.question.model.UsersDetails;

@SpringBootTest
class QuestionMapperTests  {
	
	@InjectMocks
	private QuestionMapper  questionMapper;

     @Test
     void testMapRow() throws SQLException {
       ResultSet rs = mock(ResultSet.class);
       int rowNum = 1;
       QuestionsList questionList = new QuestionsList();
       TagsList tagslist = new TagsList();
       UsersDetails userDetails = new UsersDetails();
       
       tagslist.setField1(rs.getString("c#"));
       tagslist.setField2(rs.getString("field2"));
       
       questionList.setQuestionId(rs.getInt(1));
       questionList.setQuestionName(rs.getString("questionname"));
       questionList.setDescription(rs.getString("description"));
       questionList.setNumberOfVotes(rs.getInt(12));
       questionList.setNumberOfViews(rs.getInt(14));
       questionList.setCreatedOn(rs.getString("createdon"));
       questionList.setModifiedOn(rs.getString("modifiedon"));
           
       userDetails.setUserName(rs.getString("username"));
       userDetails.setReputationScore(rs.getInt(12));
       userDetails.setNumberOfGoldBadges(rs.getInt(13));
       userDetails.setNumberOfBronzeBadges(rs.getInt(4));
       userDetails.setNumberOfSilverBadges(rs.getInt(8));
       
       questionList.setTagsList(tagslist);
       questionList.setUsersDetails(userDetails);
      
       QuestionsList result = questionMapper.mapRow(rs, rowNum);
       when(rs.getObject("questionId")).thenReturn(questionList);

       result.getQuestionId();
       

       Assertions.assertDoesNotThrow(this::doNotThrowException);
 	}
 	
 	private void doNotThrowException(){
 	    //This method will never throw exception
 	}

	

}
