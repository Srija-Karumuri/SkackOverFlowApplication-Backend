package com.example.question.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionListTest {

	@InjectMocks
	private QuestionsList questionsList;
	
	@Test
	void pagingListTest(){
		questionsList.getModifiedOn();
		questionsList.getCreatedOn();
		questionsList.getNumberOfViews();
		questionsList.getNumberOfVotes();
		questionsList.getDescription();
		questionsList.getQuestionName();
		questionsList.getUsersDetails();
		questionsList.getUsersDetails();
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	private void doNotThrowException(){
	    //This method will never throw exception
	}
}
