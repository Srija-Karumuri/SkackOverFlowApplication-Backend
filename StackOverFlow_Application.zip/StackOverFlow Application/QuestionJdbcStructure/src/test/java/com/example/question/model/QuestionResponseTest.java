package com.example.question.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest 
class QuestionResponseTest {
	
	@InjectMocks
	private QuestionsResponse questionsResponse;
	
	@Test
	void messageTest(){
		questionsResponse.getQuestions();
		questionsResponse.getQuestionDetails();
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	private void doNotThrowException(){
	    //This method will never throw exception
	}
}