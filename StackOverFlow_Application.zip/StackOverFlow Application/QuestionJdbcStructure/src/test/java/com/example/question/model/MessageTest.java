package com.example.question.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MessageTest {
	
	@InjectMocks
	private Message message;
	
	@Test
	void messageTest(){
		message.getCode();
		message.getDescription();
		message.getType();
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	private void doNotThrowException(){
	    //This method will never throw exception
	}
}