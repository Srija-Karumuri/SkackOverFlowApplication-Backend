package com.example.question.dao;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.jdbc.core.JdbcTemplate;
import com.example.question.model.QuestionsList;
import com.example.question.model.QuestionsResponse;
import com.example.question.model.Structure;
import com.example.question.model.TagsList;
import com.example.question.model.AnswerDetails;
import com.example.question.model.AnswerDetailsList;
import com.example.question.model.Answers;
import com.example.question.model.PagingDetails;
import com.example.question.model.PagingList;
import com.example.question.model.Questions;
import com.example.question.model.UsersDetails;
import com.example.question.rowmapper.QuestionMapper;
import static org.junit.jupiter.api.Assertions.assertEquals;

@SpringBootTest
class QuestionDAOImplTests {
	
	@InjectMocks
	private QuestionDAOImpl questionDaoImpl;
	
	@Mock
	private JdbcTemplate jdbcTemplate;
	
	@Test
    void getAllQuestionsTest() 
	{
		Structure structure = new Structure();		
		PagingDetails pagingDetails = new  PagingDetails();
		
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		List<QuestionsList> questionLists = new ArrayList<>();
	    QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	   
	    Page<QuestionsList> page = new PageImpl<>(questionLists);
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questionLists.add(questionList);
	    
	    List<PagingList> pagingLists =  new ArrayList<>();
	 
	    PagingList pagingList = new PagingList();
	    pagingList.setId("current");
	    pagingList.setPageNumber(1);
	    pagingLists.add(pagingList);	   
	          
        questions.setNumberOfQuestions(questionLists.size());
		questions.setQuestionsList(page.getContent());
		questionsResponse.setQuestions(questions);
		pagingDetails.setLimits(1);
		pagingDetails.setTotalNumberOfPages(1,1);
		pagingDetails.setPagingList(pagingLists);

		structure.setQuestionsResponse(questionsResponse);
		structure.setPagingDetails(pagingDetails);

        when(jdbcTemplate.query("SELECT * FROM JDBC", new QuestionMapper())).thenReturn(questionLists);
        when(jdbcTemplate.query("SELECT * FROM JDBC ORDER BY QUESTIONID ASC LIMIT "+pagingDetails.getLimits()+ " OFFSET "+1, new QuestionMapper())).thenReturn(questionLists);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class)).thenReturn(1);
	    questionDaoImpl.getAll(1,1);
	    Assertions.assertDoesNotThrow(this::doNotThrowException);
	  
	}
	
	@Test
    void getCountTest() 
	{
		 when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class)).thenReturn(1);
		 questionDaoImpl.count();
		 Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
		
	@Test
    void getPaginationTest() 
	{
		List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        int pageSize=1;
        int pageNumber=1;
        currentPage.setId("CURRENT");
		currentPage.setPageNumber(pageNumber);
        pagelist.add(currentPage);
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class)).thenReturn(1);
        questionDaoImpl.paginationStructure(1, pageSize);
        Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
    void getPaginationElseTest() 
	{
		List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        PagingList nextPage = new PagingList();
        int pageSize=1;
        int pageNumber=1;
        currentPage.setId("CURRENT");
        currentPage.setPageNumber(pageNumber);          
       
        nextPage.setId("NEXT");
        nextPage.setPageNumber((pageNumber+1));
        
        pagelist.add(currentPage);
        pagelist.add(nextPage);
       
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class)).thenReturn(2);
        questionDaoImpl.paginationStructure(1, pageSize);
        Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
	void getPaginationElse1Test() 
	{
	  List<PagingList> pagelist = new ArrayList<>();
      PagingList previousPage = new PagingList();
      
      List<QuestionsList> questionLists = new ArrayList<>();
      
      int pageSize=3;
      int pageNumber=2;
     
      previousPage.setId("PREVIOUS");
      previousPage.setPageNumber((pageNumber-1));

      pagelist.add(previousPage);
     
      when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class)).thenReturn(0);
      when(jdbcTemplate.query("SELECT * FROM JDBC", new QuestionMapper())).thenReturn(questionLists);
      questionDaoImpl.paginationStructure(2, pageSize);
      Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
    void getPaginationElse2Test() 
	{
		List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        PagingList previousPage = new PagingList();
        
        List<QuestionsList> questionLists = new ArrayList<>();
	    QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questionLists.add(questionList);
        
        int pageSize=4;
        int pageNumber=2;
        
        previousPage.setId("PREVIOUS");
        previousPage.setPageNumber((pageNumber-1));
        
        currentPage.setId("CURRENT");
        currentPage.setPageNumber(pageNumber);  
        
        pagelist.add(currentPage);
        pagelist.add(previousPage);
       
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class)).thenReturn(8);
        when(jdbcTemplate.query("SELECT * FROM JDBC", new QuestionMapper())).thenReturn(questionLists);
        questionDaoImpl.paginationStructure(2, pageSize);
        Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	
	@Test
    void getPaginationElse3Test() 
	{
		List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        PagingList previousPage = new PagingList();
        PagingList nextPage = new PagingList();
        
       
        int pageSize=2;
        int pageNumber=2;
        
        previousPage.setId("PREVIOUS");
        previousPage.setPageNumber((pageNumber-1));
        
        currentPage.setId("CURRENT");
        currentPage.setPageNumber(pageNumber); 
        
        nextPage.setId("NEXT");
        nextPage.setPageNumber((pageNumber+1));
                
        pagelist.add(currentPage);
        pagelist.add(previousPage);
        pagelist.add(nextPage);
        
       
        when(jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class)).thenReturn(3);
        questionDaoImpl.paginationStructure(2, pageSize);
        Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	
	@Test
    void getQuestionByIdTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
     	QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    AnswerDetails answerDetails = new AnswerDetails();
	    Answers answers = new Answers();	
	    List<AnswerDetailsList> answerDetailsLists= new ArrayList<AnswerDetailsList>();
	    AnswerDetailsList answerDetailsList= new AnswerDetailsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    
	    answerDetailsList.setAnswerId(1);
	    answerDetailsList.setAnswerBody("java");
	    answerDetailsList.setNumberOfVotes(12);
	    answerDetailsList.setComments("question based on programming language");
	    answerDetailsList.setQuestionId(questionList.getQuestionId());
	   
	    answers.setAnswerDetailsList(answerDetailsLists);
	    answers.setnumberOfAnswers(1);
	    answerDetails.setAnswers(answers);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questions.setQuestionDetailsList(questionList);
	    questions.setAnswerDetails(answerDetails);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(jdbcTemplate.queryForObject("SELECT * FROM JDBC WHERE QUESTIONID=?" ,new QuestionMapper(),questionList.getQuestionId())).thenReturn(questionList);
	    questionDaoImpl.getById(questionList.getQuestionId());
	    Assertions.assertDoesNotThrow(this::doNotThrowException);
	}

	@Test
    void addQuestionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(jdbcTemplate.update("INSERT INTO JDBC(QUESTIONID,QUESTIONNAME,DESCRIPTION,NUMBEROFVOTES,NUMBEROFVIEWS,MODIFIEDON,FIELD1,FIELD2,USERNAME,REPUTATIONSCORE,NUMBEROFGOLDBADGES,NUMBEROFBRONZEBADGES,NUMBEROFSILVERBADGES) values(?,?,?,?,?,?,?,?,?,?,?,?,?)",
	    		questionList.getQuestionId(),
	    		questionList.getQuestionName(),
	    		questionList.getDescription(),
	    		questionList.getNumberOfVotes(),
	    		questionList.getNumberOfViews(),
	    		questionList.getModifiedOn(),
	    		questionList.getTagsList().getField1(),
	    		questionList.getTagsList().getField2(),
	    		questionList.getUsersDetails().getUserName(),
	    		questionList.getUsersDetails().getReputationScore(),
	    		questionList.getUsersDetails().getNumberOfGoldBadges(),
	    		questionList.getUsersDetails().getNumberOfBronzeBadges(),
	    		questionList.getUsersDetails().getNumberOfSilverBadges())).thenReturn(1);
	    questionDaoImpl.save(questionList);
	    Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
    void updateQuestionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(jdbcTemplate.update("UPDATE JDBC SET QUESTIONNAME=?,DESCRIPTION=?,NUMBEROFVOTES=?,NUMBEROFVIEWS=?,MODIFIEDON=?,FIELD1=?,FIELD2=?,REPUTATIONSCORE=?,NUMBEROFGOLDBADGES=?,NUMBEROFBRONZEBADGES=?,NUMBEROFSILVERBADGES=? WHERE  QUESTIONID=?",
        		questionList.getQuestionName(),
        		questionList.getDescription(),
        		questionList.getNumberOfVotes(),
        		questionList.getNumberOfViews(),
        		questionList.getModifiedOn(),
        		questionList.getTagsList().getField1(),
        		questionList.getTagsList().getField2(),
        		questionList.getUsersDetails().getReputationScore(),
        		questionList.getUsersDetails().getNumberOfGoldBadges(),
        		questionList.getUsersDetails().getNumberOfBronzeBadges(),
        		questionList.getUsersDetails().getNumberOfSilverBadges(),
        		questionList.getQuestionId())).thenReturn(1);
        questionDaoImpl.update(questionList,questionList.getQuestionId());	
        Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
    void deleteQuestionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(jdbcTemplate.update("DELETE FROM JDBC WHERE QUESTIONID=?" , questionList.getQuestionId())).thenReturn(1);
	    assertEquals(1, questionDaoImpl.deleteById(questionList.getQuestionId()));	 
//        questionDaoImpl.deleteById(question.getQuestionResponse().getQuestionDetails().getQuestionDetailsList().get(0).getQuestionId());
	}
	
	@Test
    void updateQuestionByVotesTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(jdbcTemplate.update("UPDATE JDBC SET QUESTIONNAME=?,DESCRIPTION=?,NUMBEROFVOTES=?,NUMBEROFVIEWS=?,MODIFIEDON=?,FIELD1=?,FIELD2=?,REPUTATIONSCORE=?,NUMBEROFGOLDBADGES=?,NUMBEROFBRONZEBADGES=?,NUMBEROFSILVERBADGES=? WHERE  QUESTIONID=?",
        		questionList.getQuestionName(),
        		questionList.getDescription(),
        		questionList.getNumberOfVotes(),
        		questionList.getNumberOfViews(),
        		questionList.getModifiedOn(),
        		questionList.getTagsList().getField1(),
        		questionList.getTagsList().getField2(),
        		questionList.getUsersDetails().getReputationScore(),
        		questionList.getUsersDetails().getNumberOfGoldBadges(),
        		questionList.getUsersDetails().getNumberOfBronzeBadges(),
        		questionList.getUsersDetails().getNumberOfSilverBadges(),
        		questionList.getQuestionId())).thenReturn(1);
        questionDaoImpl.updateByVotes(questionList,questionList.getQuestionId(),questionList.getNumberOfVotes());	
        Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
    void updateQuestionByVotesExceptionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
//	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(jdbcTemplate.update("UPDATE JDBC SET QUESTIONNAME=?,DESCRIPTION=?,NUMBEROFVOTES=?,NUMBEROFVIEWS=?,MODIFIEDON=?,FIELD1=?,FIELD2=?,REPUTATIONSCORE=?,NUMBEROFGOLDBADGES=?,NUMBEROFBRONZEBADGES=?,NUMBEROFSILVERBADGES=? WHERE  QUESTIONID=?",
        		questionList.getQuestionName(),
        		questionList.getDescription(),
        		questionList.getNumberOfVotes(),
        		questionList.getNumberOfViews(),
        		questionList.getModifiedOn(),
        		questionList.getTagsList().getField1(),
        		questionList.getTagsList().getField2(),
        		questionList.getUsersDetails().getReputationScore(),
        		questionList.getUsersDetails().getNumberOfGoldBadges(),
        		questionList.getUsersDetails().getNumberOfBronzeBadges(),
        		questionList.getUsersDetails().getNumberOfSilverBadges(),
        		questionList.getQuestionId())).thenReturn(1);
        questionDaoImpl.updateByVotes(questionList,questionList.getQuestionId(), questionList.getNumberOfVotes());	
        Assertions.assertDoesNotThrow(this::doNotThrowException);
	}

	private void doNotThrowException(){
	    //This method will never throw exception
	}

}
