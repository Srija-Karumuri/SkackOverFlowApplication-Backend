package com.example.question.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.question.dao.QuestionDAOImpl;
import com.example.question.model.QuestionsList;
import com.example.question.model.QuestionsResponse;
import com.example.question.model.Structure;
import com.example.question.model.TagsList;
import com.example.question.model.AnswerDetails;
import com.example.question.model.AnswerDetailsList;
import com.example.question.model.Answers;
import com.example.question.model.PagingDetails;
import com.example.question.model.PagingList;
import com.example.question.model.Questions;
import com.example.question.model.UsersDetails;

@SpringBootTest
class QuestionServiceTests {
	
	@InjectMocks
	private QuestionService questionService;
	
	@Mock
	private QuestionDAOImpl questionDaoImpl;
	
	@Test
    void getAllQuestionsTest() 
	{
		Structure structure = new Structure();		
		PagingDetails pagingDetails = new  PagingDetails();
		
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();

		List<QuestionsList> questionLists = new ArrayList<>();
	    QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questionLists.add(questionList);
	    
	    List<PagingList> pagingLists =  new ArrayList<>();
	    PagingList pagingList = new PagingList();
	    pagingList.setId("next");
	    pagingList.setPageNumber(1);
	    
	    pagingLists.add(pagingList);
	    
	    pagingDetails.setLimits(3);
	    pagingDetails.setTotalNumberOfPages(1,3);
	    pagingDetails.setPagingList(pagingLists);
        questions.setNumberOfQuestions(1);
        questions.setQuestionsList(questionLists);
        
        questionsResponse.setQuestions(questions);
        structure.setQuestionsResponse(questionsResponse);
	    when(questionDaoImpl.getAll(1,3)).thenReturn(structure);
	    assertEquals(structure, questionService.getAll(1,3));	   
	}
	
	@Test
    void getQuestionByIdTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
     	QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    AnswerDetails answerDetails = new AnswerDetails();
	    Answers answers = new Answers();	
	    List<AnswerDetailsList> answerDetailsLists= new ArrayList<AnswerDetailsList>();
	    AnswerDetailsList answerDetailsList= new AnswerDetailsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    
	    answerDetailsList.setAnswerId(1);
	    answerDetailsList.setAnswerBody("java");
	    answerDetailsList.setNumberOfVotes(12);
	    answerDetailsList.setComments("question based on programming language");
	    answerDetailsList.setQuestionId(questionList.getQuestionId());
	   
	    answers.setAnswerDetailsList(answerDetailsLists);
	    answers.setnumberOfAnswers(1);
	    answerDetails.setAnswers(answers);
	    
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questions.setQuestionDetailsList(questionList);
	    questions.setAnswerDetails(answerDetails);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(questionDaoImpl.getById(questionList.getQuestionId())).thenReturn(structure);
	    assertEquals(structure, questionService.getById(questionList.getQuestionId()));	   
	}
	
	@Test
    void addQuestionTest() 
	{
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    when(questionDaoImpl.save(questionList)).thenReturn(1);
	    assertEquals(1, questionService.save(questionList));	   
	}
	
	@Test
    void updateQuestionTest() 
	{
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    when(questionDaoImpl.update(questionList,questionList.getQuestionId())).thenReturn(1);
	    assertEquals(1, questionService.update(questionList,questionList.getQuestionId()));	   
	}
	
	@Test
    void deleteQuestionTest() 
	{
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
        questionService.deleteById(questionList.getQuestionId());
        verify(questionDaoImpl,times(1)).deleteById(questionList.getQuestionId());

	}
	
	@Test
    void updateQuestionByVotesTest() 
	{
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    when(questionDaoImpl.updateByVotes(questionList,questionList.getQuestionId(),questionList.getNumberOfVotes())).thenReturn(1);
	    assertEquals(1, questionService.updateByVotes(questionList,questionList.getQuestionId(),questionList.getNumberOfVotes()));	   
	}
	
}
