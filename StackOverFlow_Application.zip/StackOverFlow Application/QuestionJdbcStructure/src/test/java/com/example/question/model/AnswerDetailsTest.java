package com.example.question.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest 
class AnswerDetailsTest {
	
	@InjectMocks
	private AnswerDetails answerDetails;
	
	@Test
	void messageTest(){
		answerDetails.getAnswers();
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	private void doNotThrowException(){
	    //This method will never throw exception
	}
}