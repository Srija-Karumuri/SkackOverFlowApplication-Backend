package com.example.question.model;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest 
class AnswerDetailsListTest {
	
	@InjectMocks
	private AnswerDetailsList answerDetailsList;
	
	@Test
	void messageTest(){
		answerDetailsList.getAnswerId();
		answerDetailsList.getAnswerBody();
		answerDetailsList.getComments();
		answerDetailsList.getNumberOfVotes();
		answerDetailsList.getQuestionId();
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	private void doNotThrowException(){
	    //This method will never throw exception
	}
}