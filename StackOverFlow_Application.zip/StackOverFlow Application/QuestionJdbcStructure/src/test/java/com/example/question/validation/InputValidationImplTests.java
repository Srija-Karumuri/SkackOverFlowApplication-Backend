package com.example.question.validation;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InputValidationImplTests {
	
	@InjectMocks
	private InputValidationImpl  inputValidationImpl;
	
	@Test
    void questionIdValidatorTests() 
	{
		inputValidationImpl.questionIdValidator(1);   
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
    void questionIdValidatorNegitiveTests() 
	{
		inputValidationImpl.questionIdValidator(0); 
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	@Test
    void getAllQuestionsTest() 
	{
		inputValidationImpl.userNameValidator("Srija");   
		Assertions.assertDoesNotThrow(this::doNotThrowException);
	}
	
	private void doNotThrowException(){
	    //This method will never throw exception
	}

	

}
