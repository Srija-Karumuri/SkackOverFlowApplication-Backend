package com.example.question.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.example.question.model.QuestionsList;
import com.example.question.model.QuestionsResponse;
import com.example.question.model.AnswerDetails;
import com.example.question.model.AnswerDetailsList;
import com.example.question.model.Answers;
import com.example.question.model.PagingDetails;
import com.example.question.model.PagingList;
import com.example.question.model.Questions;
import com.example.question.model.Structure;
import com.example.question.model.TagsList;
import com.example.question.model.UsersDetails;
import com.example.question.service.QuestionService;
import com.example.question.validation.InputValidator;

@SpringBootTest
class QuestionControllerTests {
	
	@InjectMocks
	private QuestionController questionController;
	
	@Mock
	private QuestionService questionService;
	
	@Mock
	InputValidator validate;
	
	@Mock
	private RabbitTemplate template;

	
	@Test
    void getAllQuestionsTest() 
	{
		
		Structure structure = new Structure();		
		PagingDetails pagingDetails = new  PagingDetails();
		
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();

		List<QuestionsList> questionLists = new ArrayList<>();
	    QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questionLists.add(questionList);
	    
	    List<PagingList> pagingLists =  new ArrayList<>();
	    PagingList pagingList = new PagingList();
	    pagingList.setId("next");
	    pagingList.setPageNumber(1);
	    
	    pagingLists.add(pagingList);
	    
	    pagingDetails.setLimits(3);
	    pagingDetails.setTotalNumberOfPages(1, 3);
	    pagingDetails.setPagingList(pagingLists);
        questions.setNumberOfQuestions(1);
        questions.setQuestionsList(questionLists);
        
        questionsResponse.setQuestions(questions);
        structure.setQuestionsResponse(questionsResponse);
        structure.setPagingDetails(pagingDetails);
	    when(questionService.getAll(1, 3)).thenReturn(structure);  
	    assertEquals(HttpStatus.OK,questionController.getAllQuestions(1, 3).getStatusCode());
	}	
	
	@Test
    void getAllQuestionsExceptionTest() 
	{
		
		Structure structure = new Structure();		
		PagingDetails pagingDetails = new  PagingDetails();
		
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();

		List<QuestionsList> questionLists = new ArrayList<>();
	    QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questionLists.add(questionList);
	    
	    List<PagingList> pagingLists =  new ArrayList<>();
	    PagingList pagingList = new PagingList();
	    pagingList.setId("next");
	    pagingList.setPageNumber(1);
	    
	    pagingLists.add(pagingList);
	    
	    pagingDetails.setLimits(3);
	    pagingDetails.setTotalNumberOfPages(1, 3);
	    pagingDetails.setPagingList(pagingLists);
        questions.setNumberOfQuestions(1);
        questions.setQuestionsList(questionLists);
        
        questionsResponse.setQuestions(questions);
        structure.setQuestionsResponse(questionsResponse);
        structure.setPagingDetails(pagingDetails);
	    when(questionService.getAll(1, 0)).thenThrow(EmptyResultDataAccessException.class);
	    assertEquals(HttpStatus.BAD_REQUEST,questionController.getAllQuestions(1, 0).getStatusCode());
	}	
	
	@Test
    void getQuestionByIdTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
     	QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    AnswerDetails answerDetails = new AnswerDetails();
	    Answers answers = new Answers();	
	    List<AnswerDetailsList> answerDetailsLists= new ArrayList<AnswerDetailsList>();
	    AnswerDetailsList answerDetailsList= new AnswerDetailsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    
	    answerDetailsList.setAnswerId(1);
	    answerDetailsList.setAnswerBody("java");
	    answerDetailsList.setNumberOfVotes(12);
	    answerDetailsList.setComments("question based on programming language");
	    answerDetailsList.setQuestionId(questionList.getQuestionId());
	   
	    answers.setAnswerDetailsList(answerDetailsLists);
	    answers.setnumberOfAnswers(1);
	    answerDetails.setAnswers(answers);
	    
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    questions.setQuestionDetailsList(questionList);
	    questions.setAnswerDetails(answerDetails);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(questionService.getById(questionList.getQuestionId())).thenReturn(structure);
	    assertEquals(HttpStatus.OK,questionController.getQuestionById(questionList.getQuestionId()).getStatusCode());
	}	
	
	@Test
    void getQuestionByIdExceptionTest() 
	{
	    when(questionService.getById(555)).thenThrow(EmptyResultDataAccessException.class);
	    ResponseEntity<?> responseEntity = questionController.getQuestionById(555);
	    assertEquals(HttpStatus.NOT_FOUND,responseEntity.getStatusCode());
	}
	
	@Test
    void addQuestionExceptionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(questionService.save(questionList)).thenReturn(1);
	    when(questionService.getById(questionList.getQuestionId())).thenReturn(structure);
	    when(validate.questionIdValidator(questionList.getQuestionId())).thenReturn(true);
	    when(validate.userNameValidator(questionList.getUsersDetails().getUserName())).thenReturn(true);
	    ResponseEntity<?> responseEntity = questionController.addQuestion(questionList);
		assertEquals(HttpStatus.BAD_REQUEST,responseEntity.getStatusCode());	   
	}
	
	@Test
    void addQuestionUserNameExceptionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
//	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(questionService.save(questionList)).thenReturn(1);
	    when(questionService.getById(questionList.getQuestionId())).thenReturn(null);
	    when(validate.questionIdValidator(questionList.getQuestionId())).thenReturn(true);
	    ResponseEntity<?> responseEntity = questionController.addQuestion(questionList);
		assertEquals(HttpStatus.BAD_REQUEST,responseEntity.getStatusCode());	
	}
	
	@Test
    void addQuestionUserNameValidatorTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(questionService.save(questionList)).thenReturn(1);
	    when(validate.questionIdValidator(questionList.getQuestionId())).thenReturn(true);
	    when(validate.userNameValidator(questionList.getUsersDetails().getUserName())).thenReturn(false);
	    ResponseEntity<?> responseEntity = questionController.addQuestion(questionList);
		assertEquals(HttpStatus.BAD_REQUEST,responseEntity.getStatusCode());		   
	}
	
	@Test
    void addQuestionQuestionIdValidatorTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    
//	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(questionService.save(questionList)).thenReturn(1);
	    ResponseEntity<?> responseEntity = questionController.addQuestion(questionList);
		assertEquals(HttpStatus.BAD_REQUEST,responseEntity.getStatusCode());		   
	}
	
	@Test
    void addQuestionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        
        when(questionService.save(questionList)).thenReturn(1);
	    when(questionService.getById(questionList.getQuestionId())).thenThrow(EmptyResultDataAccessException.class);
	    when(validate.questionIdValidator(questionList.getQuestionId())).thenReturn(true);
	    when(validate.userNameValidator(questionList.getUsersDetails().getUserName())).thenReturn(true);
	    ResponseEntity<?> responseEntity = questionController.addQuestion(questionList);
	    assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
	}
	
	
	
	@Test
    void updateQuestionTest() 
	{
		
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
//	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(questionService.getById(questionList.getQuestionId())).thenReturn(structure);
	    when(questionService.update(questionList,questionList.getQuestionId())).thenReturn(1);
	    ResponseEntity<?> responseEntity = questionController.updateQuestion(questionList,questionList.getQuestionId());	
	    assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
	}
	
	@Test
    void updateQuestionExceptionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
//	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(questionService.getById(555)).thenThrow(EmptyResultDataAccessException.class);
	    when(questionService.update(questionList,555)).thenReturn(1);
	    ResponseEntity<?> responseEntity = questionController.updateQuestion(questionList,555);	
	    assertEquals(HttpStatus.NOT_FOUND,responseEntity.getStatusCode());
	}
	
	@Test
    void updateQuestionUserNameExceptionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
	    when(questionService.update(questionList,questionList.getQuestionId())).thenReturn(1);
	    ResponseEntity<?> responseEntity = questionController.updateQuestion(questionList,questionList.getQuestionId());	
	    assertEquals(HttpStatus.BAD_REQUEST,responseEntity.getStatusCode());
	}
	
	@Test
    void deleteQuestionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        questionController.deleteQuestion(questionList.getQuestionId());
	    verify(questionService,times(1)).deleteById(questionList.getQuestionId());
	}
	
	@Test
    void deleteQuestionExceptionTest() 
	{
        when(questionService.getById(555)).thenThrow(EmptyResultDataAccessException.class);
	    ResponseEntity<?> responseEntity = questionController.deleteQuestion(555);	
	    assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
	}
	
	@Test
    void updateQuestionByVotesTest() 
	{
		
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
//	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(questionService.getById(questionList.getQuestionId())).thenReturn(structure);
	    when(questionService.updateByVotes(questionList,questionList.getQuestionId(),questionList.getNumberOfVotes())).thenReturn(1);
	    ResponseEntity<?> responseEntity = questionController.updateByVotes(questionList,questionList.getQuestionId(),questionList.getNumberOfVotes());	
	    assertEquals(HttpStatus.OK,responseEntity.getStatusCode());
	}
	
	@Test
    void updateQuestionByVotesExceptionTest() 
	{
		Structure structure = new Structure();	
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		QuestionsList questionList = new QuestionsList();
	    UsersDetails userDetails = new UsersDetails();
	    TagsList tagsList = new TagsList();
	    questionList.setQuestionId(1);
	    questionList.setQuestionName("What is Java?");
	    questionList.setDescription("Java is an object oriented programming");
	    questionList.setNumberOfVotes(22);
	    questionList.setNumberOfViews(547);
	    questionList.setCreatedOn("2022-11-24 16:39:39");
	    questionList.setModifiedOn("2022-11-25 12:51:39");
	    tagsList.setField1("sql");
	    tagsList.setField2("sql-server");
//	    userDetails.setUserName("Srija");
	    userDetails.setReputationScore(1500);
	    userDetails.setNumberOfGoldBadges(12);
	    userDetails.setNumberOfBronzeBadges(2);
	    userDetails.setNumberOfSilverBadges(3);
	    questionList.setTagsList(tagsList);
	    questionList.setUsersDetails(userDetails);
	    
	    questions.setQuestionDetailsList(questionList);
	    questionsResponse.setQuestions(questions);
	    structure.setQuestionsResponse(questionsResponse);
        when(questionService.getById(555)).thenThrow(EmptyResultDataAccessException.class);
	    when(questionService.updateByVotes(questionList,555,questionList.getNumberOfVotes())).thenReturn(1);
	    ResponseEntity<?> responseEntity = questionController.updateByVotes(questionList,555,questionList.getNumberOfVotes());	
	    assertEquals(HttpStatus.NOT_FOUND,responseEntity.getStatusCode());
	}
		

}
