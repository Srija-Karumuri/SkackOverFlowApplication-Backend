package com.example.question.model;

import java.util.List;

import lombok.NoArgsConstructor;


@NoArgsConstructor
public class PagingDetails {
	
	
	private int limits;
	private long  totalNumberOfPages;
	private List<PagingList> pagingList;
	
	public int getLimits() {
		return limits;
	}
	public void setLimits(int limits) {
		this.limits = limits;
	}
	public long  getTotalNumberOfPages() {
		return totalNumberOfPages;
	}
	public void setTotalNumberOfPages(long total, int pageSize) {
	   
	 long rem = total % pageSize;
	 long pages = total/pageSize;
	 
	 if(rem==0) {
	 this.totalNumberOfPages = pages;
	 }
	 else {
	     this.totalNumberOfPages = pages+1;
	 }
	}
	public List<PagingList> getPagingList() {
		return pagingList;
	}
	public void setPagingList(List<PagingList> pagingList) {
		this.pagingList = pagingList;
	}
	
}
