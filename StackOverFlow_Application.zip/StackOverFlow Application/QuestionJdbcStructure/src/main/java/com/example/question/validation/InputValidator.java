package com.example.question.validation;

public interface InputValidator {

	public boolean userNameValidator(String userName);

	boolean questionIdValidator(int questionId);

}
