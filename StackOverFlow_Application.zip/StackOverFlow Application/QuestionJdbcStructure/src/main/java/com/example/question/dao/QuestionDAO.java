package com.example.question.dao;

import com.example.question.model.QuestionsList;
import com.example.question.model.Structure;

public interface QuestionDAO {
	
	int deleteById(int id);
	Structure getById(int id);
	int save(QuestionsList questionsList);
	int update(QuestionsList questionsList, int id);
	Structure getAll(int pageNumber, int pageSize);
	int updateByVotes(QuestionsList questionsList, Integer id, Integer numberOfVotes);	

}
