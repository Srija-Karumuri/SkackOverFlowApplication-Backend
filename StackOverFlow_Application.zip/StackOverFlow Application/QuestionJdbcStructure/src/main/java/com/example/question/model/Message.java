package com.example.question.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Message {
	private String type;
	private int code;
	private String description;
}
