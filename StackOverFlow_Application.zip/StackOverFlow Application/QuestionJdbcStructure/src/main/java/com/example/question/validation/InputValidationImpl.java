package com.example.question.validation;

import org.springframework.stereotype.Component;

@Component
public class InputValidationImpl implements InputValidator {

		@Override
		public boolean userNameValidator(String userName) {
			return userName.matches("[A-Za-z _]{3,20}");
		}
		
		@Override
		public boolean questionIdValidator(int questionId) {
			boolean isAdded=true;
			if (questionId <= 0) {
				isAdded=false;
			}
			return isAdded;
		}

}


