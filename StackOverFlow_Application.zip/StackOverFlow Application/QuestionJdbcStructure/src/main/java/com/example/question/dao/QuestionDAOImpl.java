package com.example.question.dao;

import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.example.question.model.AnswerDetails;
import com.example.question.model.AnswerDetailsList;
import com.example.question.model.Answers;
import com.example.question.model.PagingDetails;
import com.example.question.model.PagingList;
import com.example.question.model.Questions;
import com.example.question.model.QuestionsList;
import com.example.question.model.QuestionsResponse;
import com.example.question.model.Structure;
import com.example.question.rowmapper.QuestionMapper;

@Repository
public class QuestionDAOImpl implements QuestionDAO {
	
	private static final String UPDATE_QUESTIONS_BY_ID_QUERY = "UPDATE JDBC SET QUESTIONNAME=?,DESCRIPTION=?,NUMBEROFVOTES=?,NUMBEROFVIEWS=?,MODIFIEDON=?,FIELD1=?,FIELD2=?,REPUTATIONSCORE=?,NUMBEROFGOLDBADGES=?,NUMBEROFBRONZEBADGES=?,NUMBEROFSILVERBADGES=? WHERE  QUESTIONID=?";
  	private static final String GET_QUESTIONS_BY_ID_QUERY = "SELECT * FROM JDBC WHERE QUESTIONID=?";
  	private static final String DELETE_QUESTIONS_BY_ID_QUERY = "DELETE FROM JDBC WHERE QUESTIONID=?";
  	private static final String GET_QUESTIONS_QUERY = "SELECT * FROM JDBC";
  	private static final String INSERT_QUESTIONS_QUERY = "INSERT INTO JDBC(QUESTIONID,QUESTIONNAME,DESCRIPTION,NUMBEROFVOTES,NUMBEROFVIEWS,MODIFIEDON,FIELD1,FIELD2,USERNAME,REPUTATIONSCORE,NUMBEROFGOLDBADGES,NUMBEROFBRONZEBADGES,NUMBEROFSILVERBADGES) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
  	private static final String GET_ANSWERDETAILS_QUERY="SELECT ANSWERID,ANSWERBODY,NUMBEROFVOTES,COMMENTS FROM ANSWERDETAILS A WHERE A.QUESTIONID=?";
	
  	private static final String CURRENT="current";
  	private static final String NEXT="next";
  	private static final String PREVIOUS="previous";
  	
  	private static final String DATE_FORMAT="yyyy/MM/dd HH:mm:ss";
  	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	@Override
	public Structure getAll(int pageNumber,  int pageSize) {

		Structure structure = new Structure();		
		PagingDetails pagingDetails = new  PagingDetails();
		
		QuestionsResponse questionsResponse = new QuestionsResponse();
		Questions questions = new Questions();
		
		List<QuestionsList> questionsList = jdbcTemplate.query(GET_QUESTIONS_QUERY, new QuestionMapper());
		int start = Math.min((int)PageRequest.of(pageNumber-1, pageSize).getOffset(), questionsList.size());
		Page<QuestionsList> page = new PageImpl<>(jdbcTemplate.query("SELECT * FROM JDBC ORDER BY QUESTIONID ASC LIMIT "+pageSize+ " OFFSET "+start, new QuestionMapper()));
		
		long total = questionsList.stream().count();
		
		questions.setNumberOfQuestions(total);
		questions.setQuestionsList(page.getContent());
		questionsResponse.setQuestions(questions);
		pagingDetails.setLimits(pageSize);
		pagingDetails.setTotalNumberOfPages(total,pageSize);
		pagingDetails.setPagingList(paginationStructure(pageNumber,pageSize));

		structure.setQuestionsResponse(questionsResponse);
		structure.setPagingDetails(pagingDetails);

		return structure;
	}
	
	public int count() {
		   return jdbcTemplate.queryForObject("SELECT COUNT(*) FROM JDBC", Integer.class);
	}
	
	public int paginationCount(int pageNumber,  int pageSize) {
		List<QuestionsList> questionsList = jdbcTemplate.query(GET_QUESTIONS_QUERY, new QuestionMapper());
		int start = Math.min((int)PageRequest.of(pageNumber, pageSize).getOffset(), questionsList.size());
		return count()-start;
		
	}
	
	public List<PagingList> paginationStructure(int pageNumber,int pageSize){
        List<PagingList> pagelist = new ArrayList<>();
        PagingList currentPage = new PagingList();
        PagingList nextPage = new PagingList();
        PagingList previousPage = new PagingList();
        if((count()==pageSize)&&(pageNumber==1)) {
        	currentPage.setId(CURRENT);
            currentPage.setPageNumber(pageNumber);
            
            pagelist.add(currentPage);       	
        }
        else {
	        if((pageNumber==1)) {
	            currentPage.setId(CURRENT);
	            currentPage.setPageNumber(pageNumber);          
	           
	            nextPage.setId(NEXT);
	            nextPage.setPageNumber((pageNumber+1));
	            
	            pagelist.add(currentPage);
	            pagelist.add(nextPage);
	        }  
	        else if(paginationCount(pageNumber-1, pageSize)==0) {	        	
	        	 previousPage.setId(PREVIOUS);
		         previousPage.setPageNumber((count()-pageSize-2));
		         
		         currentPage.setId("No Pages are avaliable here, go to the previous page");
		
		         pagelist.add(previousPage);
		         pagelist.add(currentPage);
	        	
	        }
	        else if((count()%pageSize==0)||(paginationCount(pageNumber-1, pageSize)<pageSize)) {
	        	 previousPage.setId(PREVIOUS);
	             previousPage.setPageNumber((pageNumber-1));
	             
	             currentPage.setId(CURRENT);
	             currentPage.setPageNumber(pageNumber);
	        	
	             pagelist.add(previousPage);
	             pagelist.add(currentPage);
	        	
	        	}
	        else {
	            currentPage.setId(CURRENT);
	            currentPage.setPageNumber(pageNumber);
	            
	            nextPage.setId(NEXT);
	            nextPage.setPageNumber((pageNumber+1));
	            
	            previousPage.setId(PREVIOUS);
	            previousPage.setPageNumber((pageNumber-1));
	
	            pagelist.add(previousPage);
	            pagelist.add(currentPage);
	            pagelist.add(nextPage);
	        }  
        
       }        
        return pagelist;
    }
	
	
	@Override
    public Structure getById(int id) {
        Structure structure = new Structure();    
        QuestionsResponse questionsResponse = new QuestionsResponse();
        Questions questions = new Questions();
                
        AnswerDetails answerDetails = new AnswerDetails();
        Answers answers= new Answers();
        
        QuestionsList questionsList = jdbcTemplate.queryForObject(GET_QUESTIONS_BY_ID_QUERY,new QuestionMapper(),id);
        List<AnswerDetailsList> answerDetailsList = jdbcTemplate.query(GET_ANSWERDETAILS_QUERY, new Object[] { id },new int[] { Types.VARCHAR },new BeanPropertyRowMapper<AnswerDetailsList>(AnswerDetailsList.class));      
        
        long total = answerDetailsList.stream().count();
        answers.setnumberOfAnswers(total);
        answers.setAnswerDetailsList(answerDetailsList);
        answerDetails.setAnswers(answers);
        
        questions.setQuestionDetailsList(questionsList);
        
        questions.setAnswerDetails(answerDetails);
        questionsResponse.setQuestionDetails(questions);
        structure.setQuestionsResponse(questionsResponse);
        return structure;
    }
	
	@Override
	public int save(QuestionsList questionsList) {
		Date date=new Date();
        SimpleDateFormat dateForm=new SimpleDateFormat(DATE_FORMAT);
        questionsList.setCreatedOn(dateForm.format(date));
        questionsList.setModifiedOn(null);
        return jdbcTemplate.update(INSERT_QUESTIONS_QUERY,
			        questionsList.getQuestionId(),
					questionsList.getQuestionName(),
					questionsList.getDescription(),
					questionsList.getNumberOfVotes(),
					questionsList.getNumberOfViews(),
					questionsList.getModifiedOn(),
					questionsList.getTagsList().getField1(),
					questionsList.getTagsList().getField2(),
					questionsList.getUsersDetails().getUserName(),
					questionsList.getUsersDetails().getReputationScore(),
					questionsList.getUsersDetails().getNumberOfGoldBadges(),
					questionsList.getUsersDetails().getNumberOfBronzeBadges(),
					questionsList.getUsersDetails().getNumberOfSilverBadges() );
	}
	
	@Override
	public int update(QuestionsList questionsList, int id) {
		Date date=new Date();
	    SimpleDateFormat dateForm=new SimpleDateFormat(DATE_FORMAT);
	    questionsList.setModifiedOn(dateForm.format(date));		 
	    return jdbcTemplate.update(UPDATE_QUESTIONS_BY_ID_QUERY,
	    		    questionsList.getQuestionName(),
	    			questionsList.getDescription(),
	    			questionsList.getNumberOfVotes(),
	    			questionsList.getNumberOfViews(),
	    			questionsList.getModifiedOn(),
	    			questionsList.getTagsList().getField1(),
	    			questionsList.getTagsList().getField2(),
	    			questionsList.getUsersDetails().getReputationScore(),
	    			questionsList.getUsersDetails().getNumberOfGoldBadges(),
	    			questionsList.getUsersDetails().getNumberOfBronzeBadges(),
	    			questionsList.getUsersDetails().getNumberOfSilverBadges(),id );
     }
	 
	 @Override
	 public int deleteById(int id) {
		return jdbcTemplate.update(DELETE_QUESTIONS_BY_ID_QUERY , id);
	 }

	 @Override
	 public int updateByVotes(QuestionsList questionsList, Integer id,Integer numberOfVotes) {
			Structure question=getById(id);
			Date date=new Date();
		    SimpleDateFormat dateForm=new SimpleDateFormat(DATE_FORMAT);
		    questionsList.setModifiedOn(dateForm.format(date));		
		    if(numberOfVotes!=null) {
		    questionsList.setNumberOfVotes(numberOfVotes);
		    }
		    else {
		    	questionsList.setNumberOfVotes(question.getQuestionsResponse().getQuestionDetails().getQuestionDetailsList().getNumberOfVotes());
		    }		  
		    return jdbcTemplate.update(UPDATE_QUESTIONS_BY_ID_QUERY,
		    		    questionsList.getQuestionName(),
		    			questionsList.getDescription(),
		    			questionsList.getNumberOfVotes(),
		    			questionsList.getNumberOfViews(),
		    			questionsList.getModifiedOn(),
		    			questionsList.getTagsList().getField1(),
		    			questionsList.getTagsList().getField2(),
		    			questionsList.getUsersDetails().getReputationScore(),
		    			questionsList.getUsersDetails().getNumberOfGoldBadges(),
		    			questionsList.getUsersDetails().getNumberOfBronzeBadges(),
		    			questionsList.getUsersDetails().getNumberOfSilverBadges(),id );
	    }
	
}