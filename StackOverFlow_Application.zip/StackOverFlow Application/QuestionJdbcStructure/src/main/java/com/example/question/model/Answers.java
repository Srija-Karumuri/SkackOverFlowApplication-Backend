package com.example.question.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_DEFAULT)
public class Answers {
	
	private long numberOfAnswers;    
    private List<AnswerDetailsList> answerDetailsList;
    
    public long getNumberOfAnswers() {
        return numberOfAnswers;
    }
    public void setnumberOfAnswers(long numberOfAnswers) {
        this.numberOfAnswers = numberOfAnswers;
    }
    
    public  List<AnswerDetailsList> getAnswerDetailsList() {
        return answerDetailsList;
    }
    public void setAnswerDetailsList(List<AnswerDetailsList> answerDetailsList) {
        this.answerDetailsList = answerDetailsList;
    }
}
