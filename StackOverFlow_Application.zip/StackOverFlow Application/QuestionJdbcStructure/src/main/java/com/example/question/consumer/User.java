//package com.example.question.consumer;
//
//import org.springframework.amqp.rabbit.annotation.RabbitListener;
//import org.springframework.stereotype.Component;
//
//import com.example.question.config.MessagingConfig;
//import com.example.question.model.Message;
//
//@Component
//public class User {
//    @RabbitListener(queues=MessagingConfig.QUEUE)
//    public void consumeMessageFromQueue(Message message) {
//        System.out.println("Message received from queue : "+message);
//    }
//
//}