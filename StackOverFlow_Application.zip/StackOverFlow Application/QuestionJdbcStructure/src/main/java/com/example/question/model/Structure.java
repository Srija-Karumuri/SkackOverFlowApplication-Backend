package com.example.question.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_DEFAULT)
public class Structure {
	
	private QuestionsResponse questionsResponse;
	private PagingDetails  pagingDetails;
	

	public QuestionsResponse getQuestionsResponse() {
		return questionsResponse;
	}

	public void setQuestionsResponse(QuestionsResponse questionsResponse) {
		this.questionsResponse = questionsResponse;
	}
	
	public PagingDetails getPagingDetails() {
		return pagingDetails;
	}
	public void setPagingDetails(PagingDetails pagingDetails) {
		this.pagingDetails = pagingDetails;
	}


}
