package com.example.question.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.question.dao.QuestionDAOImpl;
import com.example.question.model.QuestionsList;
import com.example.question.model.Structure;

@Service
public class QuestionService {
	
    @Autowired
    private  QuestionDAOImpl questionDaoImpl;
    
    public Structure getAll(int pageNumber,  int pageSize) {
        return questionDaoImpl.getAll(pageNumber, pageSize);
    }
    
    public Structure getById(int id) {
        return questionDaoImpl.getById(id);
    }
    
    public int save(QuestionsList questionsList) {
        return questionDaoImpl.save(questionsList);
    } 
    
    public int update(QuestionsList questionsList, int id) {
        return questionDaoImpl.update(questionsList,id);
    }
    
    public void deleteById(int id) {
        questionDaoImpl.deleteById(id);
    }
	
    public int updateByVotes(QuestionsList questionsList, Integer id,Integer numberOfVotes) {
        return questionDaoImpl.updateByVotes(questionsList, id, numberOfVotes);
    }
}