package com.example.question.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


@JsonInclude(Include.NON_DEFAULT)
public class Questions {

	private long numberOfQuestions;
	private List<QuestionsList> questionsList;
	private QuestionsList questionDetailsList;
	private AnswerDetails answerDetails;
	
	public long getNumberOfQuestions() {
	  return numberOfQuestions;
	}
	public void setNumberOfQuestions(long numberOfQuestions) {
		this.numberOfQuestions = numberOfQuestions;
	}

	public List<QuestionsList> getQuestionsList() {
		return questionsList;
	}
	public void setQuestionsList(List<QuestionsList> questionsList) {
		this.questionsList = questionsList;
	}
	
	public QuestionsList getQuestionDetailsList() {
		return questionDetailsList;
	}
	public void setQuestionDetailsList(QuestionsList questionDetailsList) {
		this.questionDetailsList = questionDetailsList;
	}
	
	public AnswerDetails getAnswerDetails() {
		return answerDetails;
	}
	public void setAnswerDetails(AnswerDetails answerDetails) {
		this.answerDetails = answerDetails;
	}

	
}
