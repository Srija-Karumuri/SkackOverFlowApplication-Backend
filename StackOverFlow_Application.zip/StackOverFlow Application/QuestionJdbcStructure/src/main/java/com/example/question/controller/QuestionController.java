package com.example.question.controller;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.question.config.MessagingConfig;
import com.example.question.model.Message;
import com.example.question.model.QuestionsList;
import com.example.question.model.Response;
import com.example.question.model.Structure;
import com.example.question.service.QuestionService;
import com.example.question.validation.InputValidator;

@RestController
@RequestMapping("/questions")
public class QuestionController {
	
	private static final String HTTP_STATUS_SUCCESS ="SUCCESS";
	private static final String HTTP_STATUS_BAD_REQUEST ="BAD REQUEST";
	private static final String HTTP_STATUS_NOT_FOUND ="NOT_FOUND";

	@Autowired
	private QuestionService questionService;
	
	@Autowired
	InputValidator validate;
	
	@Autowired
	private RabbitTemplate template;
	
	@GetMapping("/getAllQuestions")
    public ResponseEntity<Object>  getAllQuestions(@RequestParam(value = "pageNumber" , defaultValue = "1", required = false) int pageNumber,
            @RequestParam(value = "pageSize" , defaultValue = "3", required = false) int pageSize){
        try {	 
   	    	  return new ResponseEntity<>( questionService.getAll(pageNumber, pageSize), HttpStatus.OK);
   	      } catch(Exception e) {
   	          Response response = new Response();
   	          Message message = new Message();
   	          message.setType(HTTP_STATUS_BAD_REQUEST);
   	          message.setCode(400);
   	    	  message.setDescription("Check Page Number or Page Size");
   	          response.setMessage(message);
   	          return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST); 
   	      }
    }
    
    @GetMapping("/{questionId}")
   	public ResponseEntity<Object> getQuestionById(@PathVariable int questionId) {
   	     try {
   	    	Structure structure  = questionService.getById(questionId);	    	 
   	    	  return new ResponseEntity<>(structure, HttpStatus.OK);
   	      } catch(Exception e) {
   	          Response response = new Response();
   	          Message message = new Message();
   	          message.setType(HTTP_STATUS_NOT_FOUND);
   	          message.setCode(404);
   	    	  message.setDescription("No Records Found");
   	          response.setMessage(message);
   	          return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);           
   	      }
   	}
    
    @PostMapping("/addQuestion")
	public ResponseEntity<Object> addQuestion(@RequestBody QuestionsList question )  {
	if (validate.questionIdValidator(question.getQuestionId())) {
	  if((question.getUsersDetails().getUserName()!=null)&&(question.getQuestionName()!=null)) {
		if (!validate.userNameValidator(question.getUsersDetails().getUserName())) {
			Response response = new Response();
	        Message message = new Message();
	        message.setType(HTTP_STATUS_BAD_REQUEST);
	    	message.setCode(400);
	    	message.setDescription("Check Username");
	        response.setMessage(message);
	        return new ResponseEntity<>(message,HttpStatus.BAD_REQUEST);
		}
		try {
			questionService.getById(question.getQuestionId());
			Response response = new Response();
            Message message = new Message();
            message.setType(HTTP_STATUS_BAD_REQUEST);
	    	message.setCode(400);
	        message.setDescription("Id Already Exits");
            response.setMessage(message);
            return new ResponseEntity<>(message, HttpStatus.BAD_REQUEST);
		} catch (Exception e) {
			Response response = new Response();
            Message message = new Message();
            questionService.save(question);
            message.setType(HTTP_STATUS_SUCCESS);
	    	message.setCode(200);
	    	message.setDescription("Question Added Successfully");
            response.setMessage(message);
            response.setQuestionId(question.getQuestionId());
            template.convertAndSend(MessagingConfig.EXCHANGE, MessagingConfig.ROUTING_KEY,message);
            return new ResponseEntity<>(response,HttpStatus.OK);           
     	}
	   }
		else{
		     Response response = new Response();
			 Message message = new Message();
			 message.setType(HTTP_STATUS_BAD_REQUEST);
			 message.setCode(400);
			 message.setDescription("Username and Question name should not be null");
			 response.setMessage(message);
			 return new ResponseEntity<>(message,HttpStatus.BAD_REQUEST);
		}
	   }
	  else {
			Response response = new Response();
			 Message message = new Message();
			 message.setType(HTTP_STATUS_BAD_REQUEST);
			 message.setCode(400);
			 message.setDescription("Question id should not be null");
			 response.setMessage(message);
			 return new ResponseEntity<>(message,HttpStatus.BAD_REQUEST);	  
	  }	 
		
	 }
		
	 @PutMapping("/{questionId}")
	 public ResponseEntity<Object> updateQuestion(@RequestBody QuestionsList questionsList,@PathVariable int questionId) {  
	   if((questionsList.getUsersDetails().getUserName()==null)) {
        try {  
        	questionService.getById(questionId);
            Response response = new Response();
            Message message = new Message();
            questionService.update(questionsList,questionId);
            message.setType(HTTP_STATUS_SUCCESS);
            message.setCode(200);
            message.setDescription("Question Updated Successfully");
            response.setMessage(message);
            response.setStructure(questionService.getById(questionId));
            return new ResponseEntity<>(response,HttpStatus.OK);
        } catch(Exception e) {
	        Response response = new Response();
	        Message message = new Message();
	        message.setType(HTTP_STATUS_NOT_FOUND);
	        message.setCode(404);
	        message.setDescription("No Records Found");
	        response.setMessage(message);
	        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
	    }
	   }
	   else {
			Response response = new Response();
			 Message message = new Message();
			 message.setType(HTTP_STATUS_BAD_REQUEST);
			 message.setCode(400);
			 message.setDescription("Username can't be updated");
			 response.setMessage(message);
			 return new ResponseEntity<>(message,HttpStatus.BAD_REQUEST);	  
	  }	  
	}
		
    @DeleteMapping("/{questionId}")
    public ResponseEntity<Message> deleteQuestion(@PathVariable int questionId) {
		try {
			questionService.getById(questionId);
			questionService.deleteById(questionId);
			Response response = new Response();
            Message message = new Message();
            message.setType(HTTP_STATUS_SUCCESS);
            message.setCode(200);
            message.setDescription("Question deleted Successfully");
            response.setMessage(message);
            return new ResponseEntity<>(message,HttpStatus.OK);
		} catch (Exception e) {
			Response response = new Response();
            Message message = new Message();
            message.setType(HTTP_STATUS_SUCCESS);
            message.setCode(200);
            message.setDescription("Question deleted Successfully");
            response.setMessage(message);
            return new ResponseEntity<>(message,HttpStatus.OK);
		}
	}
    
 
    @PutMapping("/question")
    public ResponseEntity<Object> updateByVotes(@RequestBody QuestionsList questionsList,
    		@RequestParam(value="id") Integer questionId,@RequestParam(value="numberOfVotes",required = false) Integer numberOfVotes) {
    	try {
	    	 questionService.getById(questionId);
	    	 questionService.updateByVotes(questionsList, questionId, numberOfVotes);
	    	 Response response = new Response();
	         Message message = new Message();
	         message.setType(HTTP_STATUS_SUCCESS);
	         message.setCode(200);
	         message.setDescription("Question Updated Successfully");
	         response.setMessage(message);
	   	     response.setStructure(questionService.getById(questionId));
	         return new ResponseEntity<>(response,HttpStatus.OK);
    	} catch(Exception e) {
    		Response response = new Response();
	        Message message = new Message();
	        message.setType(HTTP_STATUS_NOT_FOUND);
	        message.setCode(404);
	        message.setDescription("No Record Found");
	        response.setMessage(message);
	        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
      }
    }
    
}
