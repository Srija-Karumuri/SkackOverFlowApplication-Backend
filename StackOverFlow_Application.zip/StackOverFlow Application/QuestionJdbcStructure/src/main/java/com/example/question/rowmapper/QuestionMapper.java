package com.example.question.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import org.springframework.jdbc.core.RowMapper;

import com.example.question.model.QuestionsList;
import com.example.question.model.TagsList;
import com.example.question.model.UsersDetails;

public class QuestionMapper implements RowMapper<QuestionsList>  {
	
	Date now = new Date();
    Instant current = now.toInstant();
    LocalDateTime local = LocalDateTime.ofInstant(current,ZoneId.systemDefault());


	   @Override
	   public QuestionsList mapRow(ResultSet rs, int rowNum) throws SQLException {
	  

	        QuestionsList questionList = new QuestionsList();
	        TagsList tagslist = new TagsList();
	        UsersDetails userDetails = new UsersDetails();
	        
	        tagslist.setField1(rs.getString("field1"));
	        tagslist.setField2(rs.getString("field2"));
	        
	        questionList.setQuestionId(rs.getInt("questionid"));
	        questionList.setQuestionName(rs.getString("questionname"));
	        questionList.setDescription(rs.getString("description"));
	        questionList.setNumberOfVotes(rs.getInt("numberofvotes"));
	        questionList.setNumberOfViews(rs.getInt("numberofviews"));
	        questionList.setCreatedOn(rs.getString("createdon"));
	        questionList.setModifiedOn(rs.getString("modifiedon"));
	            
	        userDetails.setUserName(rs.getString("username"));
	        userDetails.setReputationScore(rs.getInt("reputationscore"));
	        userDetails.setNumberOfGoldBadges(rs.getInt("numberofgoldbadges"));
	        userDetails.setNumberOfBronzeBadges(rs.getInt("numberofbronzebadges"));
	        userDetails.setNumberOfSilverBadges(rs.getInt("numberofsilverbadges"));
	        
	        questionList.setTagsList(tagslist);
	        questionList.setUsersDetails(userDetails);
	        
	               
	      return questionList;
	    }
}